# Test Resources

The file AndroidManifest.xml and the XML and PNG resources under res/
in this directory would typically be generated during test compilation
using gradle. Since App Inventor uses ant as its build system, these
resources are included to support the use of Robolectric as a test
runner.
