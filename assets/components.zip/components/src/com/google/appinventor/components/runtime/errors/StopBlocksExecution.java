package com.google.appinventor.components.runtime.errors;

public final class StopBlocksExecution extends RuntimeException {
}
