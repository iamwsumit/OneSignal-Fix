// -*- mode: java; c-basic-offset: 2; -*-
// Copyright 2009-2011 Google, All Rights reserved
// Copyright 2011-2012 MIT, All rights reserved
// Released under the Apache License, Version 2.0
// http://www.apache.org/licenses/LICENSE-2.0

package com.google.appinventor.components.runtime.util;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import com.google.appinventor.components.common.ScreenAnimation;

/**
 * This class supplies some support for pre-defined component animation.
 *
 * <p>For more information about animation on the Android platform, see
 * the <a href="http://code.google.com/android/documentation.html">
 * Android documentation</a> on code.google.com.
 *
 */
public final class AnimationUtil {

  private AnimationUtil() {
  }

  /*
   * Animates a component moving it horizontally.
   */
  private static void ApplyHorizontalScrollAnimation(View view, boolean left, int speed) {
    float sign = left ? 1f : -1f;
    AnimationSet animationSet = new AnimationSet(true);
    animationSet.setRepeatCount(Animation.INFINITE);
    animationSet.setRepeatMode(Animation.RESTART);

    TranslateAnimation move = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, sign * 0.70f,
        Animation.RELATIVE_TO_PARENT, sign * -0.70f, Animation.RELATIVE_TO_PARENT, 0,
        Animation.RELATIVE_TO_PARENT, 0);
    move.setStartOffset(0);
    move.setDuration(speed);
    move.setFillAfter(true);
    animationSet.addAnimation(move);
    view.startAnimation(animationSet);
  }

  /**
   * Animates a component (using pre-defined animation kinds).
   *
   * @param view  component to animate
   * @param animation  animation kind
   */
  public static void ApplyAnimation(View view, String animation) {
    // TODO(user): These string constants need to be extracted and defined somewhere else!
    // TODO(user): Also, the endless else-if is inefficient
    if (animation.equals("ScrollRightSlow")) {
      ApplyHorizontalScrollAnimation(view, false, 8000);
    } else if (animation.equals("ScrollRight")) {
      ApplyHorizontalScrollAnimation(view, false, 4000);
    } else if (animation.equals("ScrollRightFast")) {
      ApplyHorizontalScrollAnimation(view, false, 1000);
    } else if (animation.equals("ScrollLeftSlow")) {
      ApplyHorizontalScrollAnimation(view, true, 8000);
    } else if (animation.equals("ScrollLeft")) {
      ApplyHorizontalScrollAnimation(view, true, 4000);
    } else if (animation.equals("ScrollLeftFast")) {
      ApplyHorizontalScrollAnimation(view, true, 1000);
    } else if (animation.equals("Stop")) {
      view.clearAnimation();
    }
  }

  public static void ApplyOpenScreenAnimation(Activity activity, String animType) {
    if (animType == null) {
        return;
    }

    if (SdkLevel.getLevel() <= SdkLevel.LEVEL_DONUT) {
        Log.e("AnimationUtil", "Screen animations are not available on android versions less than 2.0.");
        return;
    }
    int enter = 0;
    int exit = 0;

    if (animType.equals("In And Out")) {
        enter = activity.getResources().getIdentifier("animate_in_out_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_in_out_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Slide Left")) {
        enter = activity.getResources().getIdentifier("animate_slide_left_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_slide_left_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Slide Right")) {
        enter = activity.getResources().getIdentifier("animate_swipe_right_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_swipe_right_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Slide Down")) {
        enter = activity.getResources().getIdentifier("animate_slide_down_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_slide_down_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Slide Up")) {
        enter = activity.getResources().getIdentifier("animate_slide_up_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_slide_up_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Split")) {
        enter = activity.getResources().getIdentifier("animate_split_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_split_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Shrink")) {
        enter = activity.getResources().getIdentifier("animate_shrink_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_shrink_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Card")) {
        enter = activity.getResources().getIdentifier("animate_card_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_card_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Zoom")) {
        enter = activity.getResources().getIdentifier("animate_zoom_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_zoom_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Fade")) {
        enter = activity.getResources().getIdentifier("animate_fade_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_fade_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Spin")) {
        enter = activity.getResources().getIdentifier("animate_spin_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_spin_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Diagonal")) {
        enter = activity.getResources().getIdentifier("animate_diagonal_right_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_diagonal_right_exit", "anim", activity.getPackageName());
    } else if (animType.equals("Windmill")) {
        enter = activity.getResources().getIdentifier("animate_windmill_enter", "anim", activity.getPackageName());
        exit = activity.getResources().getIdentifier("animate_windmill_exit", "anim", activity.getPackageName());
      } else
        return;
    EclairUtil.overridePendingTransitions(activity, enter, exit);
}

  /**
   * Applies a specific animation for transitioning back a screen.
   *
   * @param activity - the form which is closing
   * @param animType - the animation type
   */
  @SuppressWarnings("RegularMethodName")
  public static void ApplyCloseScreenAnimation(Activity activity, String animType) {
    if (animType == null) {
      return;
    }

    if (SdkLevel.getLevel() <= SdkLevel.LEVEL_DONUT) {
      Log.e("AnimationUtil", "Screen animations are not available on android versions less than 2.0.");
      return;
    }
    int enter = 0;
    int exit = 0;

    if (animType.equals("In And Out")) {
      enter = activity.getResources().getIdentifier("animate_in_out_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_in_out_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Slide Left")) {
      enter = activity.getResources().getIdentifier("animate_slide_left_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_slide_left_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Slide Right")) {
      enter = activity.getResources().getIdentifier("animate_swipe_right_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_swipe_right_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Slide Down")) {
      enter = activity.getResources().getIdentifier("animate_slide_down_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_slide_down_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Slide Up")) {
      enter = activity.getResources().getIdentifier("animate_slide_up_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_slide_up_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Split")) {
      enter = activity.getResources().getIdentifier("animate_split_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_split_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Shrink")) {
      enter = activity.getResources().getIdentifier("animate_shrink_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_shrink_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Card")) {
      enter = activity.getResources().getIdentifier("animate_card_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_card_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Zoom")) {
      enter = activity.getResources().getIdentifier("animate_zoom_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_zoom_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Fade")) {
      enter = activity.getResources().getIdentifier("animate_fade_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_fade_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Spin")) {
      enter = activity.getResources().getIdentifier("animate_spin_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_spin_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Diagonal")) {
      enter = activity.getResources().getIdentifier("animate_diagonal_right_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_diagonal_right_exit", "anim", activity.getPackageName());
  } else if (animType.equals("Windmill")) {
      enter = activity.getResources().getIdentifier("animate_windmill_enter", "anim", activity.getPackageName());
      exit = activity.getResources().getIdentifier("animate_windmill_exit", "anim", activity.getPackageName());
    } else
      return;

    EclairUtil.overridePendingTransitions(activity, enter, exit);
  }

}